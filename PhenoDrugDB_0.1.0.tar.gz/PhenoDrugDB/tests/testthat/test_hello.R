test_that("hello works", {
  expect_equal(hello(),"Hello, world!")
})